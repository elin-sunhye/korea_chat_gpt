package phr_solution.dto.request;

public class PatientRequestDto {
}
