package phr_solution.repository;

public class RecordRepository {
}
