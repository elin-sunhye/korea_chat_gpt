package phr_solution.dto.response;

public class PatientResponseDto {
}
