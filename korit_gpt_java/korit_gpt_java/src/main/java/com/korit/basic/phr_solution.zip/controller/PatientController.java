package phr_solution.controller;

public class PatientController {
}
