package phr_solution.entity;

public class Patient {
}
